<?php
 
include "baglan.php";
 
if(isset($_POST['guncelle'])){
 
    $sql = "UPDATE `ogrenci` 
        SET `ograd` = ?, 
            `ogrsoyad` = ?, 
            `dtarih` = ?, 
            `sinif` = ? WHERE `ogrenci`.`ogrno` = ?";
    $dizi=[
        $_POST['ad'],
        $_POST['sad'],
        $_POST['dtarih'],
        $_POST['sinif'],
        $_POST['ogrno']
    ];
    $sorgu = $baglan->prepare($sql);
    $sorgu->execute($dizi);
 
    header("Location:site.php");
}
 
$sql ="SELECT * FROM ogrenci WHERE ogrno = ?";
$sorgu = $baglan->prepare($sql);
$sorgu->execute([
    $_GET['ogrno']
]);
$satir = $sorgu->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasarım</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <header>
       <div class="container">
           <div class="row">
               <div class="col">
                   <h1 class="display-1 text-center">Tasarım Kodlama</h1>
               </div>
           </div>
           <div class="row">
               <div class="col">
                   <div class="btn-group">
                       <a href="site.php" class="btn btn-outline-primary">Tüm Öğrenciler</a>
                       <a href="ekle.php" class="btn btn-outline-primary">Öğrenci Ekle</a>
                   </div>
               </div>
           </div>
       </div>


    </header>
    <main>
        <div class="container">
        <form action="" method="post" class="row mt-2 g-3">
            <input type="hidden" name="ogrno" value="">
            <div class="col-6">
                <label for="ad" class="form-label">Adınız</label>
                <input type="text" class="form-control" name="ad">
            </div>
            <div class="col-6">
                <label for="sad" class="form-label">Soyadınız</label>
                <input type="text" class="form-control" name="sad">
            </div>
            <div class="col-6">
                <label for="sinif" class="form-label">Sınıf</label>
                <input type="text" class="form-control" name="sinif">
            </div>
            <div class="col-6">
                <label for="dtarih" class="form-label">Doğum Tarihi</label>
                <input type="date" class="form-control" name="dtarih">
            </div>
            <div class="col">
                <label for="" class="form-label">Erkek
                  <input type="radio" name="cins" value="E">
                </label>
                <label for="" class="form-label">Kız
                  <input type="radio" name="cins" value="K">
                </label>
            </div>
        
        <button type="submit" class="btn btn-primary" name="guncelle">Güncelle</button>
        </form>
    </div>
    </main>
    <footer></footer>
    </body>
</html>