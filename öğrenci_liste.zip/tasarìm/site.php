
<?php
 
include "baglan.php";
 
if(isset($_GET['sil'])){
    $sqlsil="DELETE FROM `ogrenci` WHERE `ogrenci`.`ogrno` = ?";
    $sorgusil=$baglan->prepare($sqlsil);
    $sorgusil->execute([
        $_GET['sil']
    ]);
 
    header('Location:site.php');
 
}
 
$sql ="SELECT * FROM ogrenci";
$sorgu = $baglan->prepare($sql);
$sorgu->execute();
 
?>











<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasarım</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <header>
       <div class="container">
           <div class="row">
               <div class="col">
                   <h1 class="display-1 text-center">Tasarım Kodlama</h1>
               </div>
           </div>
           <div class="row">
               <div class="col">
                   <div class="btn-group">
                       <a href="site.php" class="btn btn-outline-primary">Tüm Öğrenciler</a>
                       <a href="ekle.php" class="btn btn-outline-primary">Öğrenci Ekle</a>
                   </div>
               </div>
           </div>
       </div>


    </header>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col">
                    <table class="table">
                        <thead>
<tr>
<th>No</th>
<th>Ad</th>
<th>Soyad</th>
<th>İşlem</th>

</tr>
                        </thead>
                        <tbody>
                            <?php while($satir=$sorgu->fetch(PDO::FETCH_ASSOC)){ ?>
                              
                            
                            <tr>
                                
                             <td><?=$satir['ogrno']?></td>
                             <td><?=$satir['ograd']?></td>
                             <td><?=$satir['ogrsoyad']?></td>
                             <td>
                                 <div class="btn-group">
                                     <a href="detay.php?ogrno=<?=$satir['ogrno']?><" class="btn btn-success">Detay</a>
                                     <a href="guncelle.php?ogrno=<?=$satir['ogrno']?>" class="btn btn-secondary">Güncelle</a>
                                     <a href="?sil=<?=$satir['ogrno']?>" class="btn btn-danger" onclick="return confirm('Silinsin mi?')">Kaldır</a>

                                 </div>

                            </tr>
                         <?php } ?>
                            <tdbody>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer></footer>


</body>
</html>